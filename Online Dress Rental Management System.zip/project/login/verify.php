<?php

$email= $_POST['email'];
$pass= $_POST['pass'];


$conn = new PDO("mysql:host=localhost:3306;dbname=dr;","root","");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



$userquery= "select * from customer where customer_email='$email' AND customer_password='$pass' ";
$returnvalue=$conn->query($userquery);
$rowcount=$returnvalue->rowCount();
$table = $returnvalue->fetchAll();	
$row=$table[0];
$id= $row['customer_id'];

if($rowcount==1){
	
	header("Location: http://localhost/project/homes/index.php?cid=$id");
}
   else
   header("Location: login.php?error=1");





   ?>