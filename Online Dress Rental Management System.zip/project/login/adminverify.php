<?php
session_start();
$email= $_POST['email'];
$pass= $_POST['pass'];


$conn = new PDO("mysql:host=localhost:3306;dbname=dr;","root","");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



$userquery= "select * from admin where email='$email' AND password='$pass' ";
$returnvalue=$conn->query($userquery);
$rowcount=$returnvalue->rowCount();
if($rowcount==1){
	
	header("Location: http://localhost/project/admin/admin.php");
}
   else
   header("Location: login.php?error=1");





   ?>