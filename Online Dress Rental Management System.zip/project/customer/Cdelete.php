<?php
$id= $_GET['id'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "DELETE FROM customer WHERE customer_id='$id'";

   if( $conn->exec($sql)){
    echo "Record deleted successfully";
	header("Location: http://localhost/project/customer/customer.php");
   }

?>

    

