<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Customer details</title>
  </head>
  <body >
    <?php		
			try{				
				$conn = new PDO("mysql:host=$servername;dbname=$dbname;",$username,$password);
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	/*			
				?>
					<script>
						window.alert("Database connected");
					</script>
				<?php
	*/		
			}
			catch(PDOException $ex){
				?>
					<script>
						window.alert("Database not connected");
					</script>
				<?php
			}		
			$userquery = "SELECT * FROM customer";
			$returnvalue = $conn->query($userquery);
			$table = $returnvalue->fetchAll();		
		?>
		<div class="container">
			
			</br>
			<?php if(isset($_GET['success'])){?>
				<div class="alert alert-success">
				<strong>Success!</strong> Login successfully.
				</div>
			<?php   } ?>
			
			
			<?php if(isset($_GET['in'])){?>	
			<div>	
			<script>
			window.alert("Registration Success...!");
			</script>	
			<h2><strong>Registration Success!</strong> Inserted Customer</h2>
			</div>
			<?php } ?>
			   
			
			
			<div class="btn-success" align="center"><h1>Customer List</h1>
				</div>
			</br>
			
	
			
			<div>
			<a  class="btn btn-primary" role="button" href="http://localhost/project/admin/admin.php" >Back-To-Admin</a>
			</div>
			
			
			<table class="table">		
			<thead >
				<tr class="text-primary">
					<th>ID</th>
					<th>Name</th>
					<th>Gender</th>
					<th>Email</th>
					<th>Phone_No</th>
					<th>Address</th>
					<th>Action</th>
					
				
					
				</tr>
			</thead>
		
			<tbody>
			<?php	
	
		for($i=0; $i<count($table); $i++){
			$row=$table[$i];
				?>
				
				<tr>
					<td><?php echo $row['customer_id'] ?></td>
					<td><?php echo $row['customer_name'] ?></td>
					<td><?php echo $row['gender'] ?></td>
					<td><?php echo $row['customer_email'] ?></td>
					<td><?php echo $row['phone_num'] ?></td>
					<td><?php echo $row['customer_address'] ?></td>
					
					
					
					<td> <a onclick=" return confirm ('Are you sure?')" href="http://localhost/project/customer/Cdelete.php?id=<?php echo $row['customer_id']?>" class="btn btn-danger" type="button" > Delete</a></td>
				
					
				</tr>
				
				<?php
	
}
?>
			</tbody>
			
			</table>
			
			</div>

			

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

