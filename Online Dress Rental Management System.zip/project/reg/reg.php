<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>RegistrationForm_v2 by Colorlib</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="csss/style.css">
	</head>

	<body>
	<?php		
			try{				
				$conn = new PDO("mysql:host=$servername;dbname=$dbname;",$username,$password);
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			
				
				/*			
				?>
					<script>
						window.alert("Database connected");
					</script>
				<?php
	*/
			
			}
			catch(PDOException $ex){
		?>
				<script>
						window.alert("Database not connected");
					</script>
					<?php
			}
	?>
	
	

			

				<div class="wrapper"  align ="center"style="background-image: url('images/bg-registration-form-2.jpg');">
				<div class="inner">
				<form action="insert.php" method="POST">
				
				
				
			
			   
			   </br>
			
			   
			</br>
					<h3>Registration Form</h3>					
					<div >
						<label for="">Name</label>
						<input type="text" class="form-control"name="Name">
					</div>
						</br>
						<div >
							<label for="">Gender</label>
							<input type="text" class="form-control"name="Gender">
						</div>	
</br>						
					<div class="form-wrapper">
						<label for="">Address</label>
						<input type="text" class="form-control"name="Address">
					</div>
					<div class="form-wrapper">
						<label for="">Email</label>
						<input type="text" class="form-control"name="Email">
					</div>
					<div class="form-wrapper">
						<label for="">Phone Number</label>
						<input type="text" class="form-control"name="P_NO">
					</div>
					<div class="form-wrapper">
						<label for="">Password</label>
						<input type="password" class="form-control"name="Password">
					</div>
					<div class="form-wrapper">
						<label for="">Confirm-Password</label>
						<input type="password" class="form-control"name="Con-Pass">
					</div>
					<div class="checkbox">
						<label>
							<input type="checkbox"> I caccept the Terms of Use & Privacy Policy.
							<span class="checkmark"></span>
						</label>
					</div>
					
					
					<button type="submit"> Register now</button>
					
				</form>
			</div>
		</div>
		
	</body>
</html>