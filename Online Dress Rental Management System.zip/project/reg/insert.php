

<?php
	 $servername = "localhost";
	 $username = "root";
	 $password = "";
	 $dbname = "dr";
	 
	 //$id=$_POST['ID'];
	 $name=$_POST['Name'];
	 $gender=$_POST['Gender'];
	 $email=$_POST['Email'];
	 $address=$_POST['Address'];
     $phone=$_POST['P_NO'];
	 $email=$_POST['Email'];
	 $pass=$_POST['Password'];
	 $cpass=$_POST['Con-Pass'];
	 
	 if($pass!=$cpass){	 
		 header("Location: http://localhost/project/reg/reg.php?pc=1");		 
		
	 }
	 
	
	
		
			try{				
				$conn = new PDO("mysql:host=$servername;dbname=$dbname;",$username,$password);
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				?>
					<script>
						window.alert("Database connected");
					</script>
				<?php
			
			}
			catch(PDOException $ex){
				?>
					<script>
						window.alert("Database not connected");
					</script>
				<?php
			}		
		
  		
		$sql = "INSERT INTO customer ( customer_name, gender, phone_num, customer_email, customer_address, customer_password) VALUES ( '$name', '$gender','$phone','$email','$address', '$pass')";
        $result=$conn->query($sql);
		
		if($result){	
	    header("Location: http://localhost/project/homes/index.php");
		}