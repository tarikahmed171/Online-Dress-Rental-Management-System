<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
    <title>Add Product Form</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet" media="all">	
</head>

<body>
    <div class="page-wrapper bg-dark p-t-100 p-b-50">
        <div class="wrapper wrapper--w900">
            <div class="card card-6">
                <div class="card-heading">
                    <h2 class="title">Add Product</h2>
                </div>
                <div class="card-body">
                    <form action="allproduct/pinsert.php"  method="POST" enctype="multipart/form-data" >
                        <div class="form-row">
                            <div class="name" required="" >Product Code </div>
                            <div class="value">
                                <input class="input--style-6" placeholder='Enter Code' type="text" name="code">
                            </div>
                        </div>
                        
						 <div class="form-row">
                            <div class="name">Product Name</div>
                            <div class="value">
                                <input class="input--style-6" placeholder='Enter Product Code' type="text" name="pname">
                            </div>
                        </div>
						
                       <div class="form-row">
                            <div class="name">Category</div>
                            <div class="value">
                                <input class="input--style-6" placeholder='Enter Category'type="text" name="category">
                            </div>
                        </div>
						 <div class="form-row">
                            <div class="name">Product Price</div>
                            <div class="value">
                                <input class="input--style-6" placeholder='Enter Price' type="text" name="price">
                            </div>
                        </div>
						 <div class="form-row">
                            <div class="name">Rental Cost</div>
                            <div class="value">
                                <input class="input--style-6" placeholder='Rental Code' type="text" name="cost">
                            </div>
                        </div>
						 <div class="form-row">
                            <div class="name">Brand</div>
                            <div class="value">
                                <input class="input--style-6" placeholder='Enter Brand' type="text" name="brand">
                            </div>
                        </div>
					  
					  
					  
                        <div class="form-row">
                            <div class="name">Product Image</div>
                            <div class="value">
                                <div class="input-group js-input-file">
                                    <input class="input-file" type="file" name="img" id="file">
                                    <label class="label--file" for="file">Choose Image</label>
                                    <span class="input-file__info">No file chosen</span>
                                </div>
                                <div class="label--desc">Upload your Product Image. Max file size 50 MB</div>
                            </div>
                        </div>
						
						 <div class="card-footer">
                    <button class="btn btn--radius-2 btn--blue-2" type="submit">Submit</button>
                     </div>
						
						
						
                    </form>
                </div>
               
            </div>
        </div>
    </div>


<script src="vendor/jquery/jquery.min.js"></script>
<script src="js/global.js"></script>

</body>
</html>
