<?php
$cartid= $_GET['cartid'];
$cid=$_GET['cid'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "DELETE FROM cart WHERE cart_id='$cartid'";

   if( $conn->exec($sql)){
	header("Location: http://localhost/project/addproduct/allproduct/mycart.php?cid=$cid");
   }

?>

    