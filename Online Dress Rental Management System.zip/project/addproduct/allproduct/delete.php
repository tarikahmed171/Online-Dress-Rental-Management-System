<?php
$code= $_GET['code'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "DELETE FROM products WHERE product_code='$code'";

   if( $conn->exec($sql)){
  
	header("Location: http://localhost/project/addproduct/allproduct/allproduct.php");
   }

?>

    

