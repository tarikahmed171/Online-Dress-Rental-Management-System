<?php
$pcode= $_GET['pcode'];
$cid=$_GET['cid'];
session_start();
$_SESSION["pcode"] = $pcode;
$_SESSION["cid"] = $cid;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM products WHERE product_code='$pcode'";
	$returnvalue = $conn->query($sql);
	$table = $returnvalue->fetchAll();
	$row=$table[0];
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>My cart</title>
 
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
 
  <link href="CSScart/bootstrap.min.css" rel="stylesheet">
 
  <link href="CSScart/mdb.min.css" rel="stylesheet">
 
  <link href="CSScart/style.min.css" rel="stylesheet">
</head>

<body>

  <!-- Navbar -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
    <div class="container">

      <!-- Brand -->
      <a class="navbar-brand waves-effect" href="https://mdbootstrap.com/docs/jquery/" target="_blank">
        <strong class="blue-text">Details View </strong>
      </a>

      <!-- Collapse -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Links -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <!-- Left -->
        <ul class="navbar-nav mr-auto">
        
          <li class="nav-item">
            <a class="nav-link waves-effect" href="http://localhost/project/addproduct/allproduct/product.php?name=<?php echo $row['product_name'] ?>& cid=<?php echo $cid ?>">Back to list </a>
          </li>
         
        </ul>

        <!-- Right -->
        <ul class="navbar-nav nav-flex-icons">
		
		
		
          <li class="nav-item">
            <a class="nav-link waves-effect" href="http://localhost/project/addproduct/allproduct/mycart.php?cid=<?php echo $cid ?>">
             
              <i class="fas fa-shopping-cart"></i>
              <span class="clearfix d-none d-sm-inline-block"> My Cart </span>
            </a>
          </li>
		  
		  
          
	
          </li>
        </ul>

      </div>

    </div>
  </nav>
  

  
  <main class="mt-5 pt-4">
    <div class="container dark-grey-text mt-5">

      
      <div class="row wow fadeIn">
        
        <div class="col-md-4 mb-4">
          <img src="<?php echo $row['image']?>" class="img-fluid" alt="">
        </div>
        

       
        <div class="col-md-6 mb-4">
          <div class="p-4">
            <div class="mb-3">
              <a href="">
                <span class="badge purple mr-2"><?php echo $row['product_name']?></span>
              </a>
			  
			  <a href="">
                <span class="badge red mr-1">Price: <?php echo $row['product_price']?> Taka</span>
              </a>
			  
              <a href="">
                <span class="badge green mr-1">Rent Price: <?php echo $row['rental_cost']?> Taka only</span>
              </a>
			  
                <span class="badge purple mr-1">Brand: <?php echo $row['brand']?></span>
              </a>
              
            </div>
           
            <p class="lead font-weight-bold">Terms and conditions</p>

            <p>You can rent this product for 5 days. If more than 5 days, fine applicable (100 taka per day). Or if there is any damage to the product, fines still applicable.
            </p>
              <a class="btn btn-primary btn-md my-0 p" href="http://localhost/project/addproduct/allproduct/insertcart.php?cid=<?php echo $cid?>" type="submit">+ Add to cart
                <i class="fas fa-shopping-cart ml-1"></i>
              </a>
          </div>      
        </div>  
		
		
		
		
      </div>
      <hr>
	  
    </div>
  </main>
 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


  <script type="text/javascript" src="JScsrt/jquery-3.4.1.min.js"></script>

  <script type="text/javascript" src="JScsrt/popper.min.js"></script>

  <script type="text/javascript" src="JScsrt/bootstrap.min.js"></script>

  <script type="text/javascript" src="JScsrt/mdb.min.js"></script>

  <script type="text/javascript">
   
    new WOW().init();

  </script>
</body>

</html>
