<?php

$cartid=$_GET['cartid'];


$cid=$_GET['cid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    session_start();
   
   
   $sql = "INSERT INTO booking (booking_date, cart_id) VALUES ( curdate(), '$cartid')";
        $result=$conn->query($sql);
		
		if($result){	
	    header("Location: http://localhost/project/homes/index.php?cid=$cid");


}

?>