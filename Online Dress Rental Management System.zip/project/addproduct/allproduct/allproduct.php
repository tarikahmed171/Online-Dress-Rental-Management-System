<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";
 error_reporting(0);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Product List</title>
  </head>
  <body >
			<?php	
				$conn = new PDO("mysql:host=$servername;dbname=$dbname;",$username,$password);
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
						
			$userquery = "SELECT * FROM products";
			$returnvalue = $conn->query($userquery);
			$table = $returnvalue->fetchAll();		
		?>
		<div class="container">	
			</br>
			<div class="btn-success" align="center"><h1>Products list</h1>
				</div>
			</br>
			
		<div>
			<a  class="btn btn-primary" role="button" href="http://localhost/project/admin/admin.php" >Back-To-Admin</a>
			</div>
			
			
			
			
			
			<table class="table">		
			<thead >
				<tr class="text-primary">
				<th>Image</th>
					<th>Product Code</th>
					<th>Product Name</th>
					<th>Catagory</th>
					<th>Product Price</th>
					<th>Rental cost</th>
					<th>Brand</th>
					
					<th>Action</th>
					
				
					
				</tr>
			</thead>
		
			<tbody>
			<?php	
	
		for($i=0; $i<count($table); $i++){
			$row=$table[$i];
				?>
				
				<tr>
				<td><?php echo "<img src= '$row[image]' height='100' width='100'/>";   ?> </td>
					<td><?php echo $row['product_code'] ?></td>
					<td><?php echo $row['product_name'] ?></td>
					<td><?php echo $row['category'] ?></td>
					<td><?php echo $row['product_price'] ?></td>
					<td><?php echo $row['rental_cost'] ?></td>
					<td><?php echo $row['brand'] ?></td>
					
					
					
					<td> <a onclick=" return confirm ('Are you sure?')" href="http://localhost/project/addproduct/allproduct/delete.php?code=<?php echo $row['product_code']?>" class="btn btn-danger" type="button" > Delete</a></td>
				
					
				</tr>
				
				<?php
	
}
?>
			</tbody>
			
			</table>
		
			</div>

			

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

