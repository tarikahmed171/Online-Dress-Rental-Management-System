<?php

$cid=$_GET['cid'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    session_start();
   $pcode=	$_SESSION["pcode"];
   $cid=$_SESSION["cid"] ;
   
   $sql = "INSERT INTO cart ( customer_id, cart_date, product_code) VALUES ( '$cid', curdate(), '$pcode')";
        $result=$conn->query($sql);
if($result){	
	    header("Location: http://localhost/project/homes/index.php?cid=$cid");


}
?>