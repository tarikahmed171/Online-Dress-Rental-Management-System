
<?php
	 $servername = "localhost";
	 $username = "root";
	 $password = "";
	 $dbname = "dr";
	 
	 $code=$_POST['code'];
	 $pname=$_POST['pname'];
	 $category=$_POST['category'];
	 $price=$_POST['price'];
	 $cost=$_POST['cost'];
     $brand=$_POST['brand'];

	 
	 error_reporting(0);
	 
	 $filename=$_FILES['img']['name'];
	 $tempname=$_FILES['img']['tmp_name'];
	 $folder="image/".$filename;
	 move_uploaded_file($tempname,$folder);
   
				
		$conn = new PDO("mysql:host=$servername;dbname=$dbname;",$username,$password);
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO products (product_code, product_name, category, product_price, rental_cost, brand, image) VALUES ('$code', '$pname', '$category','$price','$cost','$brand','$folder')";
        $result=$conn->query($sql);
		header("Location: http://localhost/project/admin/admin.php");
		
		
		?>