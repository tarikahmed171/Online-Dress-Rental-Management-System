<?php
$bid= $_GET['bcode'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dr";


    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "DELETE FROM booking WHERE booking_id='$bid'";

   if( $conn->exec($sql)){
	header("Location: http://localhost/project/addproduct/allproduct/booking.php");
   }

?>